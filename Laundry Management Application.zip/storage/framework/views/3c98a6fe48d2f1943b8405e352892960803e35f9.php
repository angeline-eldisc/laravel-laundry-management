<?php $__env->startSection('title', 'Edit Admin Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>edit admin user&nbsp;-&nbsp;<?php echo e($admin->name); ?></h3>
                <form action="<?php echo e(route('users.admin.update', $admin->id)); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="name" class="form-control-label">Full Name</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="text" id="name" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e($admin->name); ?>">
                            <?php if($errors->has('name')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('name')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="name" class="form-control-label">Gender</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <div class="form-check-inline form-check">
                                <label for="inline-radio1" class="form-check-label ">
                                    <input type="radio" id="inline-radio1" name="gender" value="Male" class="form-check-input" <?php echo e($admin->gender == 'Male' ? 'checked' : ''); ?>>Male
                                </label>&nbsp;&nbsp;&nbsp;
                                <label for="inline-radio2" class="form-check-label ">
                                    <input type="radio" id="inline-radio2" name="gender" value="Female" class="form-check-input"<?php echo e($admin->gender == 'Female' ? 'checked' : ''); ?>>Female
                                </label>
                            </div>
                            <?php if($errors->has('gender')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('name')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="username" class="form-control-label">Username</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <input type="text" id="username" name="username" class="form-control <?php echo e($errors->has('username') ? 'is-invalid' : ''); ?>" value="<?php echo e($admin->username); ?>" disabled>
                            <?php if($errors->has('username')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('username')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email" class="form-control-label">Email Address</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="text" id="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e($admin->email); ?>" disabled>
                            <?php if($errors->has('email')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('email')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="phone_num" class="form-control-label">Phone Number</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <input type="text" id="phone_num" name="phone_num" class="form-control <?php echo e($errors->has('phone_num') ? 'is-invalid' : ''); ?>" value="<?php echo e($admin->phone_num); ?>">
                            <?php if($errors->has('phone_num')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('phone_num')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="address" class="form-control-label">Address</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <textarea name="address" id="address" rows="4" class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>"><?php echo e($admin->address); ?></textarea>
                            <?php if($errors->has('address')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('address')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="profile" class="col col-md-3 control-label">New Profile</label>
                        <div class="col-12 col-md-6">
                            <img width="200" height="200" />
                            <input type="file" class="uploads form-control" style="margin-top: 20px;" name="profile">
                            <?php if($errors->has('profile')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('profile')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('users.admin.index')); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--green">Update</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/users/admin/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Edit Transaction'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .select2-selection__rendered {
        line-height: calc(2.25rem + 2px) !important;
    }
    .select2-container .select2-selection--single {
        height: calc(2.25rem + 2px) !important;
    }
    .select2-selection__arrow {
        height: calc(2.25rem + 2px) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>edit transaction</h3>
                <form action="<?php echo e(route('transaction.update', $transaction->id)); ?>" method="post" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="invoice_code" class="form-control-label">Invoice Code</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="text" id="invoice_code" name="invoice_code" class="form-control <?php echo e($errors->has('invoice_code') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->invoice_code); ?>" readonly="">
                            <?php if($errors->has('invoice_code')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('invoice_code')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="member_id" class="form-control-label">Member</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="member_id" id="select2_member_id" class="select2_member_id form-control <?php echo e($errors->has('member_id') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>" <?php echo e($member->id == $transaction->member_id ? 'selected' : ''); ?>><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('member_id')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('member_id')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="additional_cost" class="form-control-label">Additional Cost</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <input type="text" id="additional_cost" name="additional_cost" class="form-control <?php echo e($errors->has('additional_cost') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->additional_cost); ?>">
                            <?php if($errors->has('additional_cost')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('additional_cost')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="discount" class="form-control-label">Discount</label>
                        </div>
                        <div class="col-12 col-md-2">
                            <input type="text" id="discount" name="discount" class="form-control <?php echo e($errors->has('discount') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->discount); ?>">
                            <?php if($errors->has('discount')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('discount')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="tax" class="form-control-label">Tax</label>
                        </div>
                        <div class="col-12 col-md-2">
                            <input type="text" id="tax" name="tax" class="form-control <?php echo e($errors->has('tax') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->tax); ?>">
                            <?php if($errors->has('tax')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('tax')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="payment_date" class="form-control-label">Payment Date</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="datetime-local" id="payment_date" name="payment_date" class="form-control mb-1 <?php echo e($errors->has('payment_date') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->payment_date); ?>">
                            <span style="font-size: 12px;">Note: Payment date can be skipped if paid status
                            <?php if($errors->has('payment_date')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('payment_date')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="paid_status" class="form-control-label">Paid Status</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <select name="paid_status" id="select2_paid_status" class="select2_paid_status form-control <?php echo e($errors->has('paid_status') ? 'is-invalid' : ''); ?>" value="<?php echo e($transaction->paid_status); ?>">
                                <option></option>
                                <option value="Paid" <?php echo e($transaction->paid_status == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                                <option value="Not yet paid" <?php echo e($transaction->paid_status == 'Not yet paid' ? 'selected' : ''); ?>>Not yet paid</option>
                            </select>
                            <?php if($errors->has('paid_status')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('paid_status')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="status" class="form-control-label">Status</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <select name="status" id="select2_status" class="select2_status form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('status')); ?>">
                                <option></option>
                                <option value="New" <?php echo e($transaction->status == 'New' ? 'selected' : ''); ?>>New</option>
                                <option value="Process" <?php echo e($transaction->status == 'Process' ? 'selected' : ''); ?>>Process</option>
                                <option value="Accepted" <?php echo e($transaction->status == 'Accepted' ? 'selected' : ''); ?>>Accepted</option>
                                <option value="Done" <?php echo e($transaction->status == 'Done' ? 'selected' : ''); ?>>Done</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('status')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('transaction.index')); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--blue">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/transaction/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Add TRansaction'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .select2-selection__rendered {
        line-height: calc(2.25rem + 2px) !important;
    }
    .select2-container .select2-selection--single {
        height: calc(2.25rem + 2px) !important;
    }
    .select2-selection__arrow {
        height: calc(2.25rem + 2px) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>add transaction</h3>
                <form action="<?php echo e(route('transactions.store')); ?>" method="post" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="invoice_code" class="form-control-label">Invoice Code</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="text" id="invoice_code" name="invoice_code" class="form-control <?php echo e($errors->has('invoice_code') ? 'is-invalid' : ''); ?>" value="<?php echo e($code); ?>" readonly="">
                            <?php if($errors->has('invoice_code')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('invoice_code')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="member_id" class="form-control-label">Member</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="member_id" id="select2_member_id" class="select2_member_id form-control <?php echo e($errors->has('member_id') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>" <?php echo e(old('member_id') == $member->id ? 'selected' : ''); ?>><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('member_id')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('member_id')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="date" class="form-control-label">Transaction Date</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="datetime-local" id="date" name="date" class="form-control <?php echo e($errors->has('date') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('date')); ?>">
                            <?php if($errors->has('date')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('date')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="due_date" class="form-control-label">Due Date</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="date" id="due_date" name="due_date" class="form-control <?php echo e($errors->has('due_date') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('due_date')); ?>">
                            <?php if($errors->has('due_date')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('due_date')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="package_id" class="form-control-label">Package</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="package_id" id="select2_package_id" class="select2_package_id form-control <?php echo e($errors->has('package_id') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($package->id); ?>" <?php echo e(old('package_id') == $package->id ? 'selected' : ''); ?>>[<?php echo e($package->type); ?>]&nbsp;<?php echo e($package->package_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('package_id')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('package_id')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="qty" class="form-control-label">Quantity</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <input type="text" id="qty" name="qty" class="form-control <?php echo e($errors->has('qty') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('qty')); ?>">
                            <?php if($errors->has('qty')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('qty')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="additional_cost" class="form-control-label">Additional Cost</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <input type="text" id="additional_cost" name="additional_cost" class="form-control <?php echo e($errors->has('additional_cost') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('additional_cost')); ?>">
                            <?php if($errors->has('additional_cost')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('additional_cost')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="discount" class="form-control-label">Discount (%)</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <input type="text" id="discount" name="discount" class="form-control <?php echo e($errors->has('discount') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('discount')); ?>">
                            <?php if($errors->has('discount')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('discount')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="tax" class="form-control-label">Tax (%)</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <input type="text" id="tax" name="tax" class="form-control <?php echo e($errors->has('tax') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('tax')); ?>">
                            <?php if($errors->has('tax')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('tax')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="payment_date" class="form-control-label">Payment Date</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="date" id="payment_date" name="payment_date" class="form-control mb-1 <?php echo e($errors->has('payment_date') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('payment_date')); ?>">
                            <span style="font-size: 12px;">Note: Payment date can be skipped if paid status is 'Not Yet Paid'.</span>
                            <?php if($errors->has('payment_date')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('payment_date')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="paid_status" class="form-control-label">Paid Status</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="paid_status" id="select2_paid_status" class="select2_paid_status form-control <?php echo e($errors->has('paid_status') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <option value="Paid" <?php echo e(old('paid_status') == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                                <option value="Not yet paid" <?php echo e(old('paid_status') == 'Not yet paid' ? 'selected' : ''); ?>>Not yet paid</option>
                            </select>
                            <?php if($errors->has('paid_status')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('paid_status')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="description" class="form-control-label">Description</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <textarea name="description" class="form-control<?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="textarea-input" rows="4" class="form-control"><?php echo e(old('description')); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('description')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--blue">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/transaction/create.blade.php ENDPATH**/ ?>
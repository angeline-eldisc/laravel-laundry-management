<?php $__env->startSection('title', 'Add Package'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .select2-selection__rendered {
        line-height: calc(2.25rem + 2px) !important;
    }
    .select2-container .select2-selection--single {
        height: calc(2.25rem + 2px) !important;
    }
    .select2-selection__arrow {
        height: calc(2.25rem + 2px) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>add package</h3>
                <form action="<?php echo e(route('packages.store')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="type" class="form-control-label">Type</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="type" id="select2_type" class="select2_type form-control <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('type')); ?>">
                                <option></option>
                                <option value="Kiloan" <?php echo e(old('type') == 'Kiloan' ? 'selected' : ''); ?>>Kiloan</option>
                                <option value="Blanket" <?php echo e(old('type') == 'Blanket' ? 'selected' : ''); ?>>Blanket</option>
                                <option value="Bed Cover" <?php echo e(old('type') == 'Bed Cover' ? 'selected' : ''); ?>>Bed Cover</option>
                                <option value="Shirt" <?php echo e(old('type') == 'Shirt' ? 'selected' : ''); ?>>Shirt</option>
                                <option value="Other" <?php echo e(old('type') == 'Other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            <?php if($errors->has('type')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('type')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="package_name" class="form-control-label">Package Name</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="text" id="package_name" name="package_name" class="form-control <?php echo e($errors->has('package_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('package_name')); ?>">
                            <?php if($errors->has('package_name')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('package_name')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="price" class="form-control-label">Price</label>
                        </div>
                        <div class="col-12 col-md-4">
                            <input type="text" id="price" name="price" class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('price')); ?>">
                            <?php if($errors->has('price')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('price')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('packages.index')); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--blue">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/package/create.blade.php ENDPATH**/ ?>
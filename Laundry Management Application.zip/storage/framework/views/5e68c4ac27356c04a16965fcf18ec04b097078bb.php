<?php $__env->startSection('title', 'Manage Cashier Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>cashier users<br><br>
                <a href="<?php echo e(route('users.cashier.create')); ?>" class="au-btn au-btn--small au-btn--blue">
                    <i class="zmdi zmdi-plus"></i>Add Cashier User
                </a>
            </h3>
            <div class="table-responsive table-data">
                <table class="table">
                    <thead>
                        <tr>
                            <td>no.</td>
                            <td></td>
                            <td style="padding-left: 20px;">nama</td>
                            <td>gender</td>
                            <td>username</td>
                            <td>phone number</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($cashiers->count() > 0): ?>
                            <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td class="text-right" width="10" style="padding-right: 0px;">
                                    <div class="img-circle-costum img-45 pull-left">
                                        <?php if($cashier->profile): ?>
                                            <img src="<?php echo e(asset('images/users/'.$cashier->profile)); ?>" alt="user" class="h-100"/>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/default.png')); ?>" alt="user" class="h-100"/>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td style="padding-left: 20px;">
                                    <div class="table-data__info">
                                        <h6><?php echo e($cashier->name); ?></h6>
                                        <span>
                                            <a href="mailto:<?php echo e($cashier->email); ?>"><?php echo e($cashier->email); ?></a>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <?php echo e($cashier->gender); ?>

                                </td>
                                <td>
                                    <?php echo e($cashier->username); ?>

                                </td>
                                <td>
                                    <span class="block-email"><?php echo e($cashier->phone_num); ?></span>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('users.cashier.destroy', $cashier->id)); ?>" method="POST" class="float-left">
                                        <span class="more">
                                            <a href="<?php echo e(route('users.cashier.edit', $cashier->id)); ?>">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                        </span>
                                        <span class="more">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" onclick="return confirm('Are you sure? You will not be able to revert this!');">
                                                <i class="zmdi zmdi-delete"></i>
                                            </button>
                                        </span>
                                        <span class="more">
                                            <a href="<?php echo e(route('users.cashier.show', $cashier->id)); ?>">
                                                <i class="zmdi zmdi-more"></i>
                                            </a>
                                        </span>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center" colspan="5">No Records Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/users/cashier/index.blade.php ENDPATH**/ ?>
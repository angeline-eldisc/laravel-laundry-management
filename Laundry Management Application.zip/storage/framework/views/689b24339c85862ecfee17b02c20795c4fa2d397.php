<?php $__env->startSection('title', 'Show Transaction'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>Detail Transaction</h3>
            <div class="p-l-44 p-b-44" style="padding: 0 44px 44px 44px;">
                <div class="fs-18">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-4">
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Invoice Code</th>
                                    <td><?php echo e($transaction->invoice_code); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Transaction Date</th>
                                    <td><?php echo e($transaction->date); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Full Name</th>
                                    <td><?php echo e($transaction->member->name); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Address</th>
                                    <td><?php echo e($transaction->member->address); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Phone Number</th>
                                    <td><?php echo e($transaction->member->phone_num); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Status Order</th>
                                    <td><?php echo e($transaction->status); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Paid Status</th>
                                    <td><?php echo e($transaction->paid_status); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Pick Up Date</th>
                                    <td><?php echo e($transaction->due_date); ?></td>
                                </tr>
                            </table>

                            <table class="table table-bordered">
                                <thead class="table-primary">
                                    <th width="5%">No</th>
                                    <th>Package</th>
                                    <th width="20%" colspan="2">Price</th>
                                    <th class="text-center" width="10%">Quantity</th>
                                    <th width="20%" colspan="2">Subtotal</th>
                                    <th width="6%"></th>
                                </thead>
                                <tbody>
                                    <?php if($transaction->count() > 0): ?>
                                        <?php $__currentLoopData = $transaction->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalAll = $data->pivot->sum('total');
                                                $discount = $totalAll * $transaction->discount/100;
                                                $tax = $totalAll * $transaction->tax/100;
                                                $totalAllPrice = $totalAll + $transaction->additional_cost + $tax - $discount;
                                            ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e($data->package_name); ?>

                                                    <br>
                                                    <span class="fs-14">(Note: <?php echo e($data->pivot->description); ?>)</span>
                                                </td>
                                                <td style="border-right-style: hidden;" width="5%">Rp</td>
                                                <td class="text-right"><?php echo e(number_format($data->price, 0, "", ".")); ?></td>
                                                <td class="text-center"><?php echo e($data->pivot->qty); ?></td>
                                                <td style="border-right-style: hidden;" width="5%">Rp</td>
                                                <td class="text-right"><?php echo e(number_format($data->pivot->total, 0, "", ".")); ?></td>
                                                <td>
                                                    
                                                    <form action="<?php echo e(route('transactions.deletePackageItem', $data->pivot->id)); ?>" method="POST" class="float-left ml-1">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure? You will not be able to revert this!');">
                                                            <i class="zmdi zmdi-delete"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="5" class="text-right">
                                                Total
                                            </td>
                                            <td style="border-right-style: hidden;" width="5%"><strong>Rp</st></td>
                                            <td class="text-right"><strong><?php echo e(number_format($totalAllPrice, 0, "", ".")); ?></st></td>
                                            <td></td>
                                        </tr>
                                        <tr style="border-right: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent;">
                                            <td colspan="7" style="text-align: right;">
                                                <span style="font-size: 12px; text-align: right;">*includes tax and discount</span>
                                            </td>
                                            <td></td>
                                        </tr>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No Record Found.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <br><br>

                    <div class="row text-center">
                        <div class="col col-md-12">
                            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary btn-lg">Back</a>
                            <a href="<?php echo e(route('transactions.printInvoice', $transaction->id)); ?>" target="_blank" class="btn btn-info btn-lg">Print</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/transaction/show.blade.php ENDPATH**/ ?>
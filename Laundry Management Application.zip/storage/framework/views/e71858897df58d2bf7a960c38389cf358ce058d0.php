<?php $__env->startSection('title', 'Show Transaction'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>Detail Transaction</h3>
            <div class="p-l-44 p-b-44" style="padding: 0 44px 44px 44px;">
                <div class="fs-18">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-4">
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Invoice Code</th>
                                    <td><?php echo e($transaction->invoice_code); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Transaction Date</th>
                                    <td><?php echo e($transaction->date); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Full Name</th>
                                    <td><?php echo e($transaction->member->name); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Address</th>
                                    <td><?php echo e($transaction->member->address); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Phone Number</th>
                                    <td><?php echo e($transaction->member->phone_num); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Status Order</th>
                                    <td><?php echo e($transaction->status); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Paid Status</th>
                                    <td><?php echo e($transaction->paid_status); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-primary text-white" width="40%">Pick Up Date</th>
                                    <td><?php echo e($transaction->due_date); ?></td>
                                </tr>
                            </table>

                            <table class="table table-bordered">
                                <thead class="table-primary">
                                    <th width="5%">No</th>
                                    <th>Package</th>
                                    <th width="20%" colspan="2">Price</th>
                                    <th class="text-center" width="10%">Quantity</th>
                                    <th width="20%" colspan="2">Total</th>
                                    <th width="10%"></th>
                                </thead>
                                <tbody>
                                    <?php if($transaction->count() > 0): ?>
                                        <?php $__currentLoopData = $transaction->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalAll = $data->pivot->sum('total');
                                                $discount = $totalAll * $transaction->discount/100;
                                                $tax = $totalAll * $transaction->tax/100;
                                                $totalAllPrice = $totalAll + $transaction->additional_cost + $tax - $discount;
                                            ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e($data->package_name); ?>

                                                    <br>
                                                    <span class="fs-14">(Note: <?php echo e($data->pivot->description); ?>)</span>
                                                </td>
                                                <td style="border-right-style: hidden;" width="5%">Rp</td>
                                                <td class="text-right"><?php echo e(number_format($data->price, 0, "", ".")); ?></td>
                                                <td class="text-center"><?php echo e($data->pivot->qty); ?></td>
                                                <td style="border-right-style: hidden;" width="5%">Rp</td>
                                                <td class="text-right"><?php echo e(number_format($data->pivot->total, 0, "", ".")); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-success float-left btn-sm ml-2" data-toggle="modal" data-target="#showItemPackage" id="showItemPackageModal" data-id="<?php echo e($data->pivot->id); ?>" data-transaction="<?php echo e($transaction->id); ?>" data-package="<?php echo e($data->id); ?>" data-qty="<?php echo e($data->pivot->qty); ?>" data-price="<?php echo e($data->price); ?>" data-total=<?php echo e($data->pivot->total); ?> data-description="<?php echo e($data->pivot->description); ?>">
                                                        <i class="zmdi zmdi-edit"></i>
                                                    </button>
                                                    
                                                    <form action="<?php echo e(route('transactions.deletePackageItem', [$transaction->id, $data->pivot->id])); ?>" method="POST" class="float-left ml-1">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure? You will not be able to revert this!');">
                                                            <i class="zmdi zmdi-delete"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="5" class="text-right">
                                                Grand Total
                                                <br>
                                                <span class="fs-14">(Grand total includes tax and discount)</span>
                                            </td>
                                            <td style="border-right-style: hidden;" width="5%"><strong>Rp</st></td>
                                            <td class="text-right"><strong><?php echo e(number_format($totalAllPrice, 0, "", ".")); ?></st></td>
                                            <td></td>
                                        </tr>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No Record Found.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <br><br>

                    <div class="row text-center">
                        <div class="col col-md-12">
                            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary btn-lg">Back</a>
                            <a href="<?php echo e(route('transactions.printInvoice', $transaction->id)); ?>" target="_blank" class="btn btn-info btn-lg">Print</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<div class="modal fade" id="showItemPackage" tabindex="-1" role="dialog" aria-labelledby="showItemPackageLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="showItemPackageLabel">Edit Item Package</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" autocomplete="off" id="formEditPackageItem">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <input type="hidden" name="ItemPackageID" id="ItemPackageID" class="form-control" readonly>
                <div class="modal-body">
                    <div class="row form-group">
                        <div class="col col-md-12">
                            <label for="package_id" class="form-control-label">Package</label>
                        </div>
                        <div class="col-12 col-md-12">
                            <select name="package_id" id="select2_package_id" class="select2_package_id form-control <?php echo e($errors->has('package_id') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($package->id); ?>" id="option_package_id" data-id="<?php echo e($package->price); ?>" <?php echo e(old('package_id') == $package->id ? 'selected' : ''); ?>>[<?php echo e($package->type); ?>]&nbsp;<?php echo e($package->package_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('package_id')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('package_id')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <label for="price" class="form-control-label">Price</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <input type="text" name="price" id="price" class="form-control" readonly>
                            <?php if($errors->has('price')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('price')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <label for="qty" class="form-control-label">Quantity</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <input type="text" id="qty" name="qty" class="form-control <?php echo e($errors->has('qty') ? 'is-invalid' : ''); ?>">
                            <?php if($errors->has('qty')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('qty')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <label for="total" class="form-control-label">Total Price</label>
                        </div>
                        <div class="col-12 col-md-10">
                            <input type="text" name="total" id="total" class="form-control" readonly>
                            <?php if($errors->has('total')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('total')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <label for="description" class="form-control-label">Description</label>
                        </div>
                        <div class="col-12 col-md-12">
                            <textarea name="description" class="form-control<?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="textarea-description" rows="4" class="form-control"></textarea>
                            <?php if($errors->has('description')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('description')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="au-btn au-btn--small au-btn--blue">Edit Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        $(document).on("click", "#showItemPackageModal", function () {
            let id = $(this).data('id');
            let transaction = $(this).data('transaction');
            let package = $(this).data('package');
            let qty = $(this).data('qty');
            let price = $(this).data('price');
            let total = $(this).data('total');
            let description = $(this).data('description');

            let route = "http://localhost:8000/transactions/"+ transaction +"/editPackageItem/" + id;
            $('#formEditPackageItem').attr('action', route);

            $("#ItemPackageID").val(id).change();
            $('#select2_package_id option').removeAttr('selected').filter('[value=' + package + ']').attr('selected', true).change();
            $("#qty").val(qty).change();
            $("#price").val(price).change();
            $("#total").val(total).change();
            $('#textarea-description').text(description).change();
        });

        $(document).on("change", "#select2_package_id", function () {
            let packagePrice = $('option:selected', this).data('id');
            let qty =  $("#qty").val();
            let total = packagePrice * qty;
            $("#price").val(packagePrice).change();
            $("#total").val(total).change();
        });

        $(document).on("change", "#qty", function () {
            let packagePrice = $('option:selected', '#select2_package_id').data('id');
            let qty =  $("#qty").val();
            let total = packagePrice * qty;
            $("#price").val(packagePrice).change();
            $("#total").val(total).change();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/transaction/show.blade.php ENDPATH**/ ?>
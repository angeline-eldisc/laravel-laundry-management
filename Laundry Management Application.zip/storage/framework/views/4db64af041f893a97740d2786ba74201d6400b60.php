<?php $__env->startSection('title', 'Manage Package'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <h3 class="title-5 m-b-25">package data table</h3>
        <div class="table-data__tool">
            <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'owner'): ?>
            <div class="table-data__tool-left">
                <a href="<?php echo e(route('packages.create')); ?>" class="au-btn au-btn-icon au-btn--blue au-btn--small">
                    <i class="zmdi zmdi-plus"></i>add package
                </a>
            </div>
            <div class="table-data__tool-right">
                Total Package&nbsp;&nbsp;:&nbsp;&nbsp;<?php echo e($packages->count()); ?>&nbsp;&nbsp;Data
            </div>
            <?php else: ?>
            <div class="table-data__tool-left">
                Total Package&nbsp;&nbsp;:&nbsp;&nbsp;<?php echo e($packages->count()); ?>&nbsp;&nbsp;Data
            </div>
            <?php endif; ?>
        </div>
        <div class="table-responsive table-responsive-data2">
            <table class="table table-data2">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Type</th>
                        <th>Package Name</th>
                        <th>Price</th>
                        <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'owner'): ?>
                        <th></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if($packages->count() > 0): ?>
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="tr-shadow">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($package->type); ?></td>
                                <td><?php echo e($package->package_name); ?></td>
                                <td>
                                    <span class="block-email">Rp <?php echo e($package->price); ?></span>
                                </td>
                                <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'owner'): ?>
                                <td>
                                    <div class="table-data-feature">
                                        <a href="<?php echo e(route('packages.edit', $package->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                            <i class="zmdi zmdi-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('packages.destroy', $package->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onclick="return confirm('Are you sure? You will not be able to revert this!');">
                                                <i class="zmdi zmdi-delete"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <tr class="spacer"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td class="text-center" colspan="6">No Records Found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/package/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="title-1">Dashboard</h2>
<div class="row m-t-10">
    <div class="col-md-6 col-lg-3">
        <div class="statistic__item">
            <h2 class="number"><?php echo e($user->count()); ?></h2>
            <span class="desc">total users</span>
            <div class="icon">
                <i class="zmdi zmdi-account-o"></i>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="statistic__item">
            <h2 class="number"><?php echo e($transaction->count()); ?></h2>
            <span class="desc">total transaction</span>
            <div class="icon">
                <i class="zmdi zmdi-shopping-cart"></i>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="statistic__item">
            <h2 class="number"><?php echo e($member->count()); ?></h2>
            <span class="desc">total member</span>
            <div class="icon">
                <i class="zmdi zmdi-account-o"></i>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="statistic__item">
            <h2 class="number"><?php echo e($package->count()); ?></h2>
            <span class="desc">total package</span>
            <div class="icon">
                <i class="zmdi zmdi-calendar-note"></i>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="fas fa-exchange-alt"></i>Waiting for Order to be Picked Up</h3>
            <div class="table-responsive table-data">
                <table class="table">
                    <thead>
                        <tr>
                            <td>code</td>
                            <td>date</td>
                            <td>paid status</td>
                            <td>member</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($acceptedTransactions->count() > 0): ?>
                            <?php $__currentLoopData = $acceptedTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accepted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($accepted->invoice_code); ?></td>
                                    <td><?php echo e($accepted->date); ?></td>
                                    <td>
                                        <?php if($accepted->paid_status == 'Paid'): ?>
                                            <span class="status--process">Paid</span>
                                        <?php else: ?>
                                            <span class="status--denied">Not yet paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($accepted->member->name); ?></td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('transactions.index')); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="More">
                                                <i class="zmdi zmdi-more"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center" colspan="6">No Records Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="fas fa-exchange-alt"></i>New Order</h3>
            <div class="table-responsive table-data">
                <table class="table">
                    <thead>
                        <tr>
                            <td>code</td>
                            <td>paid status</td>
                            <td>member</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($newTransactions->count() > 0): ?>
                            <?php $__currentLoopData = $newTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($new->invoice_code); ?></td>
                                    <td>
                                        <?php if($new->paid_status == 'Paid'): ?>
                                            <span class="status--process">Paid</span>
                                        <?php else: ?>
                                            <span class="status--denied">Not yet paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($new->member->name); ?></td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('transactions.index')); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="More">
                                                <i class="zmdi zmdi-more"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center" colspan="6">No Records Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="user-data m-b-30">
            <h3 class="title-3 m-b-30"><i class="fas fa-exchange-alt"></i>Process Order</h3>
            <div class="table-responsive table-data">
                <table class="table">
                    <thead>
                        <tr>
                            <td>code</td>
                            <td>paid status</td>
                            <td>member</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($processTransactions->count() > 0): ?>
                            <?php $__currentLoopData = $processTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($process->invoice_code); ?></td>
                                    <td>
                                        <?php if($process->paid_status == 'Paid'): ?>
                                            <span class="status--process">Paid</span>
                                        <?php else: ?>
                                            <span class="status--denied">Not yet paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($process->member->name); ?></td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('transactions.index')); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="More">
                                                <i class="zmdi zmdi-more"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center" colspan="6">No Records Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/dashboard.blade.php ENDPATH**/ ?>
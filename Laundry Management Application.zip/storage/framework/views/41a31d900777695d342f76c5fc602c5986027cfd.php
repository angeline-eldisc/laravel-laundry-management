<?php $__env->startSection('title'); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1>Login</h1>
    <form method="POST" action="<?php echo e(route('login')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="txt_field">
            <input type="text" name="username" required>
            <span></span>
            <label>Username or Email Address</label>
        </div>

        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="padding-left: 5px;">
                <span class="mt-1" style="color: red; font-size: 14px;"><?php echo e($message); ?></span>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="txt_field">
            <input type="password" name="password" required>
            <span></span>
            <label>Password</label>
        </div>

        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="padding-left: 5px;">
                <span class="mt-2" style="color: red; font-size: 14px;"><?php echo e($message); ?></span>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" value="Login" class="mb-5 mt-4">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/auth/login.blade.php ENDPATH**/ ?>
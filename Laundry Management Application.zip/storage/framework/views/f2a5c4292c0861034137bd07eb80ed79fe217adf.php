<header class="header-desktop">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="header-wrap">
                <div class="form-header"></div>
                <div class="header-button">
                    <div class="noti-wrap"></div>
                    <div class="account-wrap">
                        <div class="account-item clearfix js-item-menu">
                            <div class="image">
                                <?php if(Auth::user()->profile == ''): ?>
                                    <img src="<?php echo e(asset('images/default.png')); ?>" width="45" alt="user" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/users/' . Auth::user()->profile)); ?>" width="45" alt="user" />
                                <?php endif; ?>
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="#"><?php echo e(Auth::user()->name); ?></a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <?php if(Auth::user()->profile == ''): ?>
                                                <img src="<?php echo e(asset('images/default.png')); ?>" alt="user" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/users/' . Auth::user()->profile)); ?>" alt="user" />
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#"><?php echo e(Auth::user()->name); ?></a>
                                        </h5>
                                        <span class="email"><?php echo e(Auth::user()->role); ?></span>
                                    </div>
                                </div>
                                <div class="account-dropdown__body">
                                    <div class="account-dropdown__item">
                                        <a href="
                                        <?php if(Auth::user()->role == 'admin'): ?>
                                            <?php echo e(route('users.admin.show', Auth::user()->id)); ?>

                                        <?php elseif(Auth::user()->role == 'cashier'): ?>
                                            <?php echo e(route('users.cashier.show', Auth::user()->id)); ?>

                                        <?php else: ?>
                                            <?php echo e(route('users.owner.show', Auth::user()->id)); ?>

                                        <?php endif; ?>">
                                            <i class="zmdi zmdi-account"></i>Account</a>
                                    </div>
                                    <div class="account-dropdown__item">
                                        <a href="<?php echo e(Route('users.resetPassword', Auth::user()->id)); ?>">
                                            <i class="zmdi zmdi-settings"></i>Reset Password</a>
                                    </div>
                                </div>
                                <div class="account-dropdown__footer">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                            <i class="zmdi zmdi-power"></i><?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/layouts/inc/header_desktop.blade.php ENDPATH**/ ?>
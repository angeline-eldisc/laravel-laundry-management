<?php $__env->startSection('title', ' - Contact'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Sections -->
<div class="main" style="padding-top: 80px;">
    <div class="main_container">
        <div class="main_img-container" style="margin-right: 3rem;">
            <img src="<?php echo e(asset('frontend/images/contact.svg')); ?>" alt="Picture 7" id="contact_img">
        </div>
        <div class="main_content">
            <h1>Laundry Management</h1>
            <h2>Contact Us</h2>
            <p>If you have any question, you can contact us!</p>
        </div>
    </div>
</div>

<div class="main"><div class="divider"></div></div>

<!-- Contact Sections -->
<div class="main">
    <div class="containers">
        <div class="main_content">
            <h1>Contact Us</h1>
            <div class="row mt-5">
                <div class="col-md-6" style="margin-left: auto; margin-right: auto;">
                    <div class="contact_container">
                        <div class="contact_list">
                            <i class="fa-solid fa-building contact_icon"></i>
                            <span style="padding-left: 30px;"><?php echo e($outlet->name); ?></span>
                        </div>
                        <div class="contact_list">
                            <i class="fa-solid fa-phone contact_icon"></i>
                            <span><?php echo e($outlet->phone_num); ?></span>
                        </div>
                        <div class="contact_list">
                            <i class="fa-solid fa-map-location-dot contact_icon"></i>
                            <span><?php echo e($outlet->address); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/pages/contact.blade.php ENDPATH**/ ?>
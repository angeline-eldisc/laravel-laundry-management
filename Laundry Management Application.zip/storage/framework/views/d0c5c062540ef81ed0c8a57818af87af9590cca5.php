<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transaction Report</title>
    <style>
        th {
            width: auto!important;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Invoice Code</th>
            <th>Member</th>
            <th>Member's Address</th>
            <th>Member's Phone Number</th>
            <th>Transaction Date</th>
            <th>Due Date</th>
            <th>Payment Date</th>
            <th>Package</th>
            <th>Quantity</th>
            <th>Additional Cost</th>
            <th>Discount</th>
            <th>Tax</th>
            <th>Status</th>
            <th>Paid Status</th>
            <th>Description</th>
        </tr>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $transaction->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($transaction->invoice_code); ?></td>
            <td><?php echo e($transaction->member->name); ?></td>
            <td><?php echo e($transaction->member->address); ?></td>
            <td><?php echo e($transaction->member->phone_num); ?></td>
            <td><?php echo e($transaction->date); ?></td>
            <td><?php echo e($transaction->due_date); ?></td>
            <td>
                <?php if($transaction->payment_date == NULL): ?>
                    -
                <?php else: ?>
                    <?php echo e($transaction->payment_date); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($transaction->packages->pluck('package_name')->implode(', ')); ?></td>
            <td><?php echo e($transaction->pivot->pluck('qty')->implode(', ')); ?></td>
            <td>
                <?php if($transaction->additional_cost == NULL || $transaction->additional_cost == 0 ): ?>
                    -
                <?php else: ?>
                    Rp <?php echo e($transaction->additional_cost); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($transaction->discount != NULL): ?>
                    <?php echo e($transaction->discount); ?>&nbsp;%
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td>
                <?php if($transaction->tax != NULL): ?>
                    <?php echo e($transaction->tax); ?>&nbsp;%
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td><?php echo e($transaction->status); ?></td>
            <td><?php echo e($transaction->paid_status); ?></td>
            <td>
                <?php if( $transaction->pivot->pluck('description') != NULL): ?>
                    <?php echo e($transaction->pivot->pluck('description')->implode(', ')); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/report/transcation_excel.blade.php ENDPATH**/ ?>
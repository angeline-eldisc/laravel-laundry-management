<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-settings"></i>Reset Password</h3>
                <form action="<?php echo e(route('users.reset', Auth::user()->id)); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="password" class="form-control-label">Password</label>
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="password" id="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('password')); ?>">
                            <?php if($errors->has('password')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('password')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col col-md-3">
                            <label for="password-confirm" class="form-control-label"><?php echo e(__('Confirm Password')); ?></label>
                        </div>

                        <div class="col-12 col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('users.admin.index')); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--blue">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/users/reset_password.blade.php ENDPATH**/ ?>
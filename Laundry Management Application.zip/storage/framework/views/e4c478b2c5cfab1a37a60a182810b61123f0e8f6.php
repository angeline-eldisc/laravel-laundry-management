<?php $__env->startSection('title', 'Edit Transaction'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .select2-selection__rendered {
        line-height: calc(2.25rem + 2px) !important;
    }
    .select2-container .select2-selection--single {
        height: calc(2.25rem + 2px) !important;
    }
    .select2-selection__arrow {
        height: calc(2.25rem + 2px) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body card-block p-5">
                <h3 class="title-3 m-b-30"><i class="zmdi zmdi-account-calendar"></i>edit transaction</h3>
                <form action="<?php echo e(route('transactions.update', $detailtransaction->id)); ?>" method="post" class="form-horizontal" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="package_id" class="form-control-label">Package</label>
                        </div>
                        <div class="col-12 col-md-5">
                            <select name="package_id" id="select2_package_id" class="select2_package_id form-control <?php echo e($errors->has('package_id') ? 'is-invalid' : ''); ?>">
                                <option></option>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($package->id); ?>" <?php echo e($detailtransaction->package_id == $package->id ? 'selected' : ''); ?>>[<?php echo e($package->type); ?>]&nbsp;<?php echo e($package->package_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('package_id')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('package_id')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="qty" class="form-control-label">Quantity</label>
                        </div>
                        <div class="col-12 col-md-3">
                            <input type="text" id="qty" name="qty" class="form-control <?php echo e($errors->has('qty') ? 'is-invalid' : ''); ?>" value="<?php echo e($detailtransaction->qty); ?>">
                            <?php if($errors->has('qty')): ?>
                                <small class="form-text" style="color: red">
                                    <?php echo e($errors->first('qty')); ?>

                                </small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3"></div>
                        <div class="col-12 col-md-9">
                            <a href="<?php echo e(route('transactions.show', $detailtransaction->transaction_id)); ?>" class="btn btn-secondary">Back</a>
                            <button type="submit" class="au-btn au-btn--small au-btn--blue">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Aplikasi Pengelolahan Laundry\resources\views/transaction/editPackageItem.blade.php ENDPATH**/ ?>
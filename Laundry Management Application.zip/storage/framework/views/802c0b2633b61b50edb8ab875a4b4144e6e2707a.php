<?php $__env->startSection('title', ' - About'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Sections -->
<div class="main" style="padding-top: 80px;">
    <div class="main_container">
        <div class="main_img-container">
            <img src="<?php echo e(asset('frontend/images/about.svg')); ?>" alt="Picture 3" id="about_img">
        </div>
        <div class="main_content left-content">
            <h1>Laundry Management</h1>
            <h2>About</h2>
            <p>All about this website is in here.</p>
            <a href="#about">
                <button class="main_btn">
                    Read More
                </button>
            </a>
        </div>
    </div>
</div>

<div class="main" id="about"><div class="divider"></div></div>

<!-- About Sections -->
<div class="main">
    <div class="containers">
        <div class="main_content">
            <h2>About</h2>
            <p class="about-paragraph paragraph"><?php echo e($title); ?> is laundry website that helps our customer to keep track of their laundry. Our website also provide fast and efficient result, making it easier for our customer to track their laundry. This website's purpose is to fulfill our final assignment in Psychology and Design Thinking Subject.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\President University\Psychology and Design Thinking for Information Technology Practitioners\Week 16\Laundry Management Application\resources\views/pages/about.blade.php ENDPATH**/ ?>